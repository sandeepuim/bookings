<?php
/**
 * Template Name: Hotel Results
 * 
 * Template for displaying hotel search results
 */

// Get the header
get_header();

// Get search parameters
$search_params = array(
    'country' => isset($_GET['country_code']) ? sanitize_text_field($_GET['country_code']) : '',
    'city' => isset($_GET['city_code']) ? sanitize_text_field($_GET['city_code']) : '',
    'checkin' => isset($_GET['check_in']) ? sanitize_text_field($_GET['check_in']) : '',
    'checkout' => isset($_GET['check_out']) ? sanitize_text_field($_GET['check_out']) : '',
    'adults' => isset($_GET['adults']) ? intval($_GET['adults']) : 1,
    'children' => isset($_GET['children']) ? intval($_GET['children']) : 0,
    'rooms' => isset($_GET['rooms']) ? intval($_GET['rooms']) : 1,
);

// Validate search parameters
$is_valid_search = !empty($search_params['country']) && 
                  !empty($search_params['city']) && 
                  !empty($search_params['checkin']) && 
                  !empty($search_params['checkout']) &&
                  $search_params['adults'] > 0 &&
                  $search_params['rooms'] > 0;

?>

<div class="container">
    <div class="hotel-search-container">
        <?php 
        // Include the search form
        include(get_template_directory() . '/templates/hotel-search.php'); 
        ?>
        
        <div id="search-results" class="hotel-search-results">
            <?php if ($is_valid_search): ?>
                <div class="loading-indicator">
                    <div class="spinner"></div>
                    <p>Searching for hotels...</p>
                </div>
                <script>
                    // Trigger search on page load if valid parameters
                    jQuery(document).ready(function($) {
                        // Give a small delay to allow the page to render and countries to load
                        setTimeout(function() {
                            // Fill the form with the search parameters
                            $('#country_code').val('<?php echo esc_js($search_params['country']); ?>').trigger('change');
                            
                            // Set a timeout to wait for cities to load
                            setTimeout(function() {
                                $('#city_code').val('<?php echo esc_js($search_params['city']); ?>');
                                $('#check_in').val('<?php echo esc_js($search_params['checkin']); ?>');
                                $('#check_out').val('<?php echo esc_js($search_params['checkout']); ?>');
                                $('#adults').val('<?php echo esc_js($search_params['adults']); ?>');
                                $('#children').val('<?php echo esc_js($search_params['children']); ?>');
                                $('#rooms').val('<?php echo esc_js($search_params['rooms']); ?>');
                                
                                // Submit the form
                                $('#hotel-search-form').submit();
                            }, 1000);
                        }, 500);
                    });
                </script>
            <?php else: ?>
                <div class="no-results">
                    <h3>Search for Hotels</h3>
                    <p>Use the search form above to find hotels for your trip.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>