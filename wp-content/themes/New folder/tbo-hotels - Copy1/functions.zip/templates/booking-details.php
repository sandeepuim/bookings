<?php
/**
 * Template Name: Booking Details
 *
 * Step 3: Call TBO BookingDetail API and show booking summary
 *
 * URL: /booking-details/?ref=xxxx
 */
get_header();

// TODO: Get booking reference from URL
// TODO: Call BookingDetail API and show booking summary

?>
<div class="booking-details-page">
    <h2>Booking Details</h2>
    <!-- BookingDetail API response and summary will appear here -->
</div>
<?php get_footer(); ?>
