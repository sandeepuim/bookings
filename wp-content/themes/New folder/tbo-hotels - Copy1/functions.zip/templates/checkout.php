<?php
/**
 * Template Name: Checkout
 *
 * Step 1: Call TBO PreBook API and show guest details form
 *
 * URL: /checkout/?booking_code=xxxx
 */
get_header();

// TODO: Get booking_code from URL and call PreBook API
// TODO: If PreBook successful, show guest details form
// TODO: On form submit, POST to /confirm-booking/

?>
<div class="checkout-page">
    <h2>Checkout</h2>
    <!-- PreBook API response and guest form will appear here -->
</div>
<?php get_footer(); ?>
