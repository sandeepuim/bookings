<?php
/**
 * Template Name: Confirm Booking
 *
 * Step 2: Call TBO Book API and save booking info
 *
 * URL: /confirm-booking/
 */
get_header();

// TODO: Get guest details and booking_code from POST
// TODO: Call Book API and save booking info
// TODO: Redirect to /booking-details/?ref=xxxx on success

?>
<div class="confirm-booking-page">
    <h2>Confirm Booking</h2>
    <!-- Book API response and confirmation will appear here -->
</div>
<?php get_footer(); ?>
