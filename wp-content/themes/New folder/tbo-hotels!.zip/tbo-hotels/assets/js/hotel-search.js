/**
 * TBO Hotels Search JavaScript
 * Handles the hotel search form functionality and AJAX requests
 */

jQuery(document).ready(function($) {
    var searchState = {
        countries: [],
        cities: [],
        searchResults: []
    };
    
    // Cache DOM elements
    var $form = $('#hotel-search-form');
    var $countrySelect = $('#country_code');
    var $citySelect = $('#city_code');
    var $resultsContainer = $('#search-results');
    var $searchButton = $('.search-button');
    
    // Load countries on page load
    loadCountries();
    
    // Country change handler
    $countrySelect.on('change', function() {
        var countryCode = $(this).val();
        
        if (countryCode) {
            loadCities(countryCode);
        } else {
            $citySelect.prop('disabled', true).html('<option value="">Select Country First</option>');
        }
    });
    
    // Form submission handler
    $form.on('submit', function(e) {
        e.preventDefault();
        performHotelSearch();
    });
    
    /**
     * Load countries from API
     */
    function loadCountries() {
        showLoading($countrySelect, 'Loading countries...');
        
        $.ajax({
            url: tbo_hotels_params.ajax_url,
            type: 'POST',
            data: {
                action: 'tbo_hotels_get_countries',
                nonce: tbo_hotels_params.nonce
            },
            success: function(response) {
                console.log('Countries API response:', response);
                
                if (response.success && response.data) {
                    searchState.countries = response.data;
                    populateCountrySelect(response.data);
                } else {
                    showError($countrySelect, 'Unable to load countries. Please try again.');
                }
            },
            error: function() {
                showError($countrySelect, 'Error loading countries. Please check your connection.');
            },
            complete: function() {
                hideLoading($countrySelect);
            }
        });
    }
    
    /**
     * Load cities for selected country
     */
    function loadCities(countryCode) {
        showLoading($citySelect, 'Loading cities...');
        $citySelect.prop('disabled', true);
        
        $.ajax({
            url: tbo_hotels_params.ajax_url,
            type: 'POST',
            data: {
                action: 'tbo_hotels_get_cities',
                country_code: countryCode,
                nonce: tbo_hotels_params.nonce
            },
            success: function(response) {
                console.log('Cities API response:', response);
                
                if (response.success && response.data) {
                    searchState.cities = response.data;
                    populateCitySelect(response.data);
                } else {
                    showError($citySelect, 'Unable to load cities. Please try again.');
                }
            },
            error: function() {
                showError($citySelect, 'Error loading cities. Please check your connection.');
            },
            complete: function() {
                hideLoading($citySelect);
                $citySelect.prop('disabled', false);
            }
        });
    }
    
    /**
     * Perform hotel search
     */
    function performHotelSearch() {
        var formData = {
            action: 'tbo_hotels_search_hotels',
            city_code: $('#city_code').val(),
            check_in: $('#check_in').val(),
            check_out: $('#check_out').val(),
            rooms: $('#rooms').val(),
            adults: $('#adults').val(),
            children: $('#children').val(),
            nonce: tbo_hotels_params.nonce
        };
        
        // Validate form data
        if (!formData.city_code || !formData.check_in || !formData.check_out) {
            alert('Please fill in all required fields.');
            return;
        }
        
        // Show loading state
        $searchButton.prop('disabled', true).text('Searching...');
        $resultsContainer.html('<div class="loading-spinner">Searching for hotels...</div>');
        
        console.log('Hotel search request:', formData);
        
        $.ajax({
            url: tbo_hotels_params.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                console.log('Hotel search response:', response);
                
                if (response.success && response.data) {
                    searchState.searchResults = response.data.Hotels || [];
                    displaySearchResults(response.data);
                } else {
                    $resultsContainer.html('<div class="error-message">No hotels found. Please try different search criteria.</div>');
                }
            },
            error: function() {
                $resultsContainer.html('<div class="error-message">Error searching for hotels. Please try again.</div>');
            },
            complete: function() {
                $searchButton.prop('disabled', false).text('Search Hotels');
            }
        });
    }
    
    /**
     * Populate country select options
     */
    function populateCountrySelect(countries) {
        var options = '<option value="">Select Country</option>';
        
        countries.forEach(function(country) {
            options += '<option value="' + country.Code + '">' + country.Name + '</option>';
        });
        
        $countrySelect.html(options);
    }
    
    /**
     * Populate city select options
     */
    function populateCitySelect(cities) {
        var options = '<option value="">Select City</option>';
        
        cities.forEach(function(city) {
            options += '<option value="' + city.Code + '">' + city.Name + '</option>';
        });
        
        $citySelect.html(options);
    }
    
    /**
     * Display search results
     */
    function displaySearchResults(data) {
        console.log('Displaying search results:', data);
        console.log('Hotels array:', data.Hotels);
        
        if (!data.Hotels || data.Hotels.length === 0) {
            $resultsContainer.html('<div class="no-results">No hotels found for your search criteria.</div>');
            return;
        }
        
        console.log('First hotel structure:', data.Hotels[0]);
        
        var html = '<div class="search-results-header">';
        html += '<h2>Search Results</h2>';
        html += '<p>Found ' + data.TotalHotels + ' hotels</p>';
        html += '</div>';
        
        html += '<div class="hotels-grid">';
        
        data.Hotels.forEach(function(hotel) {
            html += buildHotelCard(hotel);
        });
        
        html += '</div>';
        
        $resultsContainer.html(html);
        
        // Scroll to results
        $('html, body').animate({
            scrollTop: $resultsContainer.offset().top - 100
        }, 500);
    }
    
    /**
     * Build individual hotel card HTML
     */
    function buildHotelCard(hotel) {
        console.log('Building hotel card for hotel:', hotel);
        
        // Try multiple possible field names for hotel name
        var hotelName = hotel.HotelName || hotel.Name || hotel.hotel_name || hotel.title || 'Unknown Hotel';
        var hotelCode = hotel.HotelCode || hotel.Code || hotel.hotel_code || '';
        var currency = hotel.Currency || hotel.CurrencyCode || 'USD';
        var rooms = hotel.Rooms || hotel.RoomDetails || hotel.room_details || [];
        
        console.log('Hotel name extracted:', hotelName);
        console.log('Hotel code extracted:', hotelCode);
        console.log('Available hotel fields:', Object.keys(hotel));
        
        var html = '<div class="hotel-card" data-hotel-code="' + hotelCode + '">';
        html += '<div class="hotel-header">';
        html += '<h3 class="hotel-name">' + hotelName + '</h3>';
        html += '<span class="hotel-code">Code: ' + hotelCode + '</span>';
        html += '</div>';
        
        if (rooms.length > 0) {
            html += '<div class="hotel-rooms">';
            html += '<h4>Available Rooms:</h4>';
            
            rooms.slice(0, 3).forEach(function(room) {
                var roomName = room.Name ? room.Name.join(', ') : 'Standard Room';
                var inclusion = room.Inclusion || 'Room Only';
                var basePrice = 'Price on request';
                
                if (room.DayRates && room.DayRates.length > 0 && room.DayRates[0].length > 0) {
                    var price = room.DayRates[0][0].BasePrice;
                    if (price && price > 0) {
                        basePrice = price.toFixed(2) + ' ' + currency;
                    }
                }
                
                html += '<div class="room-option">';
                html += '<div class="room-name">' + roomName + '</div>';
                html += '<div class="room-inclusion">' + inclusion + '</div>';
                html += '<div class="room-price">' + basePrice + '</div>';
                html += '</div>';
            });
            
            html += '</div>';
        }
        
        html += '<div class="hotel-actions">';
        html += '<button class="btn-book-now" data-hotel-code="' + hotelCode + '">Book Now</button>';
        html += '</div>';
        
        html += '</div>';
        
        return html;
    }
    
    /**
     * Show loading state for select element
     */
    function showLoading($element, message) {
        $element.html('<option value="">' + message + '</option>');
    }
    
    /**
     * Hide loading state
     */
    function hideLoading($element) {
        // Loading will be replaced by actual options
    }
    
    /**
     * Show error message
     */
    function showError($element, message) {
        $element.html('<option value="">Error loading data</option>');
        console.error(message);
    }
    
    // Book now button handler (delegate event)
    $(document).on('click', '.btn-book-now', function() {
        var hotelCode = $(this).data('hotel-code');
        alert('Booking functionality for hotel ' + hotelCode + ' would be implemented here.');
        // Here you would implement the booking flow
    });
    
    // Set default dates (today + 1 day for check-in, today + 2 days for check-out)
    function setDefaultDates() {
        var today = new Date();
        var checkIn = new Date(today);
        checkIn.setDate(today.getDate() + 1);
        var checkOut = new Date(today);
        checkOut.setDate(today.getDate() + 2);
        
        $('#check_in').val(checkIn.toISOString().split('T')[0]);
        $('#check_out').val(checkOut.toISOString().split('T')[0]);
    }
    
    // Initialize default dates
    setDefaultDates();
});