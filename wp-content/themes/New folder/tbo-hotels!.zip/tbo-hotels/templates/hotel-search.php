<?php
/**
 * Template Name: Hotel Search
 * 
 * Template for displaying the hotel search form and results
 *
 * @package TBO_Hotels
 */

// Get the header
get_header();
?>

<div class="hotel-search-wrapper">
    <div class="container">
        <div class="hotel-search-container">
            <h1 class="search-title"><?php esc_html_e('Find Your Perfect Hotel', 'tbo-hotels'); ?></h1>
            
            <div class="search-form-container">
                <form id="hotel-search-form" class="hotel-search-form" method="post">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="country_code"><?php esc_html_e('Country', 'tbo-hotels'); ?></label>
                            <select id="country_code" name="country_code" required>
                                <option value=""><?php esc_html_e('Select Country', 'tbo-hotels'); ?></option>
                                <!-- Countries will be populated via JavaScript -->
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="city_code"><?php esc_html_e('City', 'tbo-hotels'); ?></label>
                            <select id="city_code" name="city_code" required disabled>
                                <option value=""><?php esc_html_e('Select Country First', 'tbo-hotels'); ?></option>
                                <!-- Cities will be populated via JavaScript -->
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="check_in"><?php esc_html_e('Check In', 'tbo-hotels'); ?></label>
                            <input type="date" id="check_in" name="check_in" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="check_out"><?php esc_html_e('Check Out', 'tbo-hotels'); ?></label>
                            <input type="date" id="check_out" name="check_out" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="rooms"><?php esc_html_e('Rooms', 'tbo-hotels'); ?></label>
                            <select id="rooms" name="rooms">
                                <?php for ($i = 1; $i <= 5; $i++) : ?>
                                    <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="adults"><?php esc_html_e('Adults', 'tbo-hotels'); ?></label>
                            <select id="adults" name="adults">
                                <?php for ($i = 1; $i <= 6; $i++) : ?>
                                    <option value="<?php echo esc_attr($i); ?>" <?php selected($i, 2); ?>><?php echo esc_html($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="children"><?php esc_html_e('Children', 'tbo-hotels'); ?></label>
                            <select id="children" name="children">
                                <?php for ($i = 0; $i <= 4; $i++) : ?>
                                    <option value="<?php echo esc_attr($i); ?>"><?php echo esc_html($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row submit-row">
                        <button type="submit" class="search-button">
                            <?php esc_html_e('Search Hotels', 'tbo-hotels'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div id="search-results" class="hotel-search-results">
            <!-- Results will be loaded here via AJAX -->
        </div>
    </div>
</div>

<?php
// Get the footer
get_footer();