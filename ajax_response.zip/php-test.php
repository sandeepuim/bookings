<?php
// Basic PHP test script
phpinfo();
?>